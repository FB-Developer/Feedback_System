export class FBfaculty{
  fname:string;
  fdept:string;
}
