import {FBsection} from'./fbsectiondt'
export class FBroot{
  dept:string;
  sem:string;
  class:string;
  batch:string;
  academicyear : string;
  degree:string;
  sectionList:FBsection[];
}
