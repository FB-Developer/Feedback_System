import {FBsubject} from'./fbsubjectdt'
export class FBsection{
  section:string;
  subjectList:FBsubject[];
}
