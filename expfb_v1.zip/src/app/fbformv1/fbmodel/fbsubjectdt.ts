import {FBfaculty} from'./fbfacultydt'
export class FBsubject{
  subname:string;
  facultyList:FBfaculty[];
}
